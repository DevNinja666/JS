import { currentLang } from './config.js';

export function initContactForm() {
    const form = document.getElementById('contactForm');
    
    if (form) {
        const newForm = form.cloneNode(true);
        form.parentNode.replaceChild(newForm, form);
        
        newForm.addEventListener('submit', (e) => {
            e.preventDefault();
            alert(currentLang === 'ru' 
                ? 'Спасибо за ваше сообщение! Мы свяжемся с вами в ближайшее время.' 
                : 'Thank you for your message! We will contact you soon.');
            newForm.reset();
        });
    }
}

