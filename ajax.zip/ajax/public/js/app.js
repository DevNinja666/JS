import { initTheme } from './theme.js';
import { initLanguage } from './language.js';
import { initNavigation } from './navigation.js';
import { initSlider } from './slider.js';
import { initScrollTop } from './scrollTop.js';
import { initMobileMenu } from './mobileMenu.js';
import { initContactForm } from './contactForm.js';

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initLanguage();
    initNavigation();
    initSlider();
    initScrollTop();
    initMobileMenu();
    initContactForm();
});
