import { updateLanguage } from './language.js';
import { initSlider } from './slider.js';
import { initContactForm } from './contactForm.js';

let internalLinksHandlerInitialized = false;

export function updateActiveNavLink(url) {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if ((url === '/' && (href === '/' || href === '')) || 
            (url !== '/' && href === url)) {
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        }
    });
}

export function loadPage(url, pushState = true) {
    const mainContent = document.getElementById('mainContent');
    if (!mainContent) return;
    
    if (url === '/' || url === '') {
        fetch('/')
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newContent = doc.querySelector('.main-content');
                if (newContent) {
                    mainContent.innerHTML = newContent.innerHTML;
                    
                    initSlider();
                    initContactForm();
                    updateLanguage();
                    updateActiveNavLink('/');
                    
                    if (pushState) {
                        history.pushState({ url: '/' }, '', '/');
                    }
                }
            })
            .catch(error => console.error('Error loading page:', error));
    } else {
        fetch(url)
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const pageContent = doc.querySelector('.page-content');
                
                if (pageContent) {
                    mainContent.innerHTML = pageContent.innerHTML;
                    initContactForm();
                    updateLanguage();
                    updateActiveNavLink(url);
                    
                    if (pushState) {
                        history.pushState({ url: url }, '', url);
                    }
                }
            })
            .catch(error => console.error('Error loading page:', error));
    }
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

export function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const href = link.getAttribute('href');
            
            if (href === '/') {
                loadPage('/');
            } else {
                loadPage(href);
            }
            
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            
            const nav = document.querySelector('.nav');
            if (nav) {
                nav.classList.remove('active');
            }
        });
    });
    
    if (!internalLinksHandlerInitialized) {
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            if (!link) return;
            
            const href = link.getAttribute('href');
            
            if (href && (href.startsWith('/') || href.startsWith('./')) && !href.startsWith('//') && !href.startsWith('#')) {
                if (href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('tel:')) {
                    return;
                }
                
                e.preventDefault();
                
                if (link.classList.contains('nav-link')) {
                    const allNavLinks = document.querySelectorAll('.nav-link');
                    allNavLinks.forEach(l => l.classList.remove('active'));
                    link.classList.add('active');
                }
                
                if (href === '/' || href === './') {
                    loadPage('/');
                } else {
                    loadPage(href);
                }
                
                updateActiveNavLink(href);
                
                const nav = document.querySelector('.nav');
                if (nav) {
                    nav.classList.remove('active');
                }
            }
        });
        
        internalLinksHandlerInitialized = true;
    }
    
    if (!window.popstateHandlerAdded) {
        window.addEventListener('popstate', (e) => {
            if (e.state) {
                loadPage(e.state.url, false);
                updateActiveNavLink(e.state.url);
            }
        });
        window.popstateHandlerAdded = true;
    }
}

