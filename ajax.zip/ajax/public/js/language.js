import { translations, currentLang, setCurrentLang } from './config.js';

export function initLanguage() {
    const langToggle = document.getElementById('langToggle');
    
    updateLanguage();
    
    if (langToggle) {
        langToggle.addEventListener('click', () => {
            const newLang = currentLang === 'ru' ? 'en' : 'ru';
            setCurrentLang(newLang);
            updateLanguage();
        });
    }
}

export function updateLanguage() {
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (translations[currentLang] && translations[currentLang][key]) {
            if (element.tagName === 'INPUT' && element.type === 'submit') {
                element.value = translations[currentLang][key];
            } else {
                element.textContent = translations[currentLang][key];
            }
        }
    });
    
    const dateElements = document.querySelectorAll('[data-i18n-ru]');
    dateElements.forEach(element => {
        if (currentLang === 'ru') {
            element.textContent = element.getAttribute('data-i18n-ru');
        } else {
            element.textContent = element.getAttribute('data-i18n-en');
        }
    });
    
    if (translations[currentLang] && translations[currentLang]['title']) {
        document.title = translations[currentLang]['title'];
    }
}

