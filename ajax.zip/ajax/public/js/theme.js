import { currentTheme, setCurrentTheme } from './config.js';

export function initTheme() {
    const themeToggle = document.getElementById('themeToggle');
    const html = document.documentElement;
    
    if (currentTheme === 'light') {
        html.setAttribute('data-theme', 'light');
        if (themeToggle) {
            themeToggle.querySelector('.theme-icon').textContent = '🌙';
        }
    } else {
        html.setAttribute('data-theme', 'dark');
        if (themeToggle) {
            themeToggle.querySelector('.theme-icon').textContent = '☀️';
        }
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            setCurrentTheme(newTheme);
            
            if (newTheme === 'light') {
                html.setAttribute('data-theme', 'light');
                themeToggle.querySelector('.theme-icon').textContent = '🌙';
            } else {
                html.setAttribute('data-theme', 'dark');
                themeToggle.querySelector('.theme-icon').textContent = '☀️';
            }
        });
    }
}

